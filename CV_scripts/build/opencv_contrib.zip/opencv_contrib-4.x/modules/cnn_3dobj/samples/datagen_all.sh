./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/01.ply -label_class=1 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/02.ply -label_class=1 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/03.ply -label_class=1 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/04.ply -label_class=1 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/05.ply -label_class=1 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/06.ply -label_class=1 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/07.ply -label_class=1 -label_item=7 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/aeroplane/08.ply -label_class=1 -label_item=8 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/aeroplane_pascal/ -semisphere=0

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/01.ply -label_class=2 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/02.ply -label_class=2 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/03.ply -label_class=2 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/04.ply -label_class=2 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/05.ply -label_class=2 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bicycle/06.ply -label_class=2 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bicycle_pascal/ -z_range=0.6

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/01.ply -label_class=3 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/02.ply -label_class=3 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/03.ply -label_class=3 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/04.ply -label_class=3 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/05.ply -label_class=3 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/boat/06.ply -label_class=3 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/boat_pascal/ -z_range=0.6

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/01.ply -label_class=4 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/02.ply -label_class=4 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/03.ply -label_class=4 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/04.ply -label_class=4 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/05.ply -label_class=4 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/06.ply -label_class=4 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/07.ply -label_class=4 -label_item=7 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bottle/08.ply -label_class=4 -label_item=8 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bottle_pascal/ -z_range=0.5

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/01.ply -label_class=5 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/02.ply -label_class=5 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/03.ply -label_class=5 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/04.ply -label_class=5 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/05.ply -label_class=5 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/bus/06.ply -label_class=5 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/bus_pascal/ -z_range=0.2

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/01.ply -label_class=6 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/02.ply -label_class=6 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/03.ply -label_class=6 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/04.ply -label_class=6 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/05.ply -label_class=6 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/06.ply -label_class=6 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/07.ply -label_class=6 -label_item=7 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/08.ply -label_class=6 -label_item=8 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/09.ply -label_class=6 -label_item=9 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/car/10.ply -label_class=6 -label_item=10 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/car_pascal/ -z_range=0.5

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/01.ply -label_class=7 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/02.ply -label_class=7 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/03.ply -label_class=7 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/04.ply -label_class=7 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/05.ply -label_class=7 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/06.ply -label_class=7 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/07.ply -label_class=7 -label_item=7 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/08.ply -label_class=7 -label_item=8 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/09.ply -label_class=7 -label_item=9 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/chair/10.ply -label_class=7 -label_item=10 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/chair_pascal/ -z_range=0.6

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/01.ply -label_class=8 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/02.ply -label_class=8 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/03.ply -label_class=8 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/04.ply -label_class=8 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/05.ply -label_class=8 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/06.ply -label_class=8 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/07.ply -label_class=8 -label_item=7 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/08.ply -label_class=8 -label_item=8 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/09.ply -label_class=8 -label_item=9 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/10.ply -label_class=8 -label_item=10 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/11.ply -label_class=8 -label_item=11 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/diningtable/12.ply -label_class=8 -label_item=12 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/diningtable_pascal/ -z_range=0.6

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/motorbike/01.ply -label_class=9 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/motorbike_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/motorbike/02.ply -label_class=9 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/motorbike_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/motorbike/03.ply -label_class=9 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/motorbike_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/motorbike/04.ply -label_class=9 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/motorbike_pascal/ -z_range=0.5
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/motorbike/05.ply -label_class=9 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/motorbike_pascal/ -z_range=0.5

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/01.ply -label_class=10 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/02.ply -label_class=10 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/03.ply -label_class=10 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/04.ply -label_class=10 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/05.ply -label_class=10 -label_item=5 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/sofa/06.ply -label_class=10 -label_item=6 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/sofa_pascal/ -z_range=0.6

./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/train/01.ply -label_class=11 -label_item=1 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/train_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/train/02.ply -label_class=11 -label_item=2 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/train_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/train/03.ply -label_class=11 -label_item=3 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/train_pascal/ -z_range=0.2
./sphereview_test -plymodel=/Users/yidawang/Documents/database/PASCAL3D+_release1.1/CAD/train/04.ply -label_class=11 -label_item=4 -bakgrdir=/Users/yidawang/Documents/database/backgrd_pascal/train_pascal/ -z_range=0.2